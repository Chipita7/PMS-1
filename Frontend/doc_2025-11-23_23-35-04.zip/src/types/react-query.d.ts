declare module '@tanstack/react-query' {
    export * from '@tanstack/react-query'
}
