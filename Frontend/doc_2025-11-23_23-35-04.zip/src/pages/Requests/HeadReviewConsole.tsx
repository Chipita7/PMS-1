import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ChevronLeft, Users, ClipboardList, CheckCircle, XCircle, UserPlus } from "lucide-react";
import { toast } from "react-hot-toast";
import { projectRequestService } from "@/services/projectRequestService";

const initialEvaluationRoles = [
  "Business Analyst",
  "Innovation Chapter",
  "Subject Matter Expert",
  "Stakeholder",
];

const refinementRoles = [
  "Head of Engineering",
  "Head of Data & AI",
  "Product Owner",
  "Information Security",
  "DevSecOps Team",
  "Subject Matter Expert",
];

const HeadReviewConsole: React.FC = () => {
  const navigate = useNavigate();
  const { role, id } = useParams<{ role: string; id: string }>();
  const requestId = Number(id);

  const [loading, setLoading] = React.useState(false);
  const [tasks, setTasks] = React.useState<any[]>([]);
  const [assignInputsInitial, setAssignInputsInitial] = React.useState<Record<string, string>>({});
  const [assignInputsRefine, setAssignInputsRefine] = React.useState<Record<string, string>>({});

  const currentRole = role || "member";

  const loadTasks = React.useCallback(async () => {
    if (!requestId) return;
    try {
      const t = await projectRequestService.getReviewTasks(requestId);
      setTasks(Array.isArray(t) ? t : []);
    } catch (e: any) {
      console.warn("Failed to load review tasks:", e?.message || e);
      setTasks([]);
    }
  }, [requestId]);

  React.useEffect(() => {
    loadTasks();
  }, [loadTasks]);

  const isTaskComplete = (t: any) => {
    const s = (t?.status || t?.Status || "").toString().toLowerCase();
    return t?.completed === true || s === "completed" || s === "done" || s === "approved";
  };

  const allResponsesReceived = tasks.length > 0 && tasks.every(isTaskComplete);
  const initialTasks = React.useMemo(
    () => tasks.filter((t) => {
      const role = (t?.assigneeRole || t?.AssigneeRole || '').toString().toLowerCase();
      return initialEvaluationRoles.some((r) => r.toLowerCase() === role);
    }),
    [tasks]
  );
  const initialAllDone = initialTasks.length > 0 && initialTasks.every(isTaskComplete);

  const handleAssign = async (phase: "initial" | "refinement", roleName: string, username: string) => {
    if (!requestId || !username) return;
    setLoading(true);
    try {
      await projectRequestService.assignReviewers(requestId, {
        assignedTeam: roleName,
        assignedTo: username,
        assigneeRole: roleName,
        reviewerType: phase,
      });
      // Also generate reviewer-specific tasks from templates for this role
      try {
        await projectRequestService.generateTasksForReviewerType(requestId, roleName, username);
      } catch (genErr: any) {
        // Non-fatal
        console.warn("Task generation failed:", genErr?.message || genErr);
      }
      toast.success(`Assigned ${username} for ${phase === "initial" ? "Initial Evaluation" : "Refinement"} (${roleName}) and generated tasks`);
      await loadTasks();
      if (phase === "initial") {
        setAssignInputsInitial((p) => ({ ...p, [roleName]: "" }));
      } else {
        setAssignInputsRefine((p) => ({ ...p, [roleName]: "" }));
      }
    } catch (e: any) {
      toast.error(e?.message || "Failed to assign reviewer");
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!requestId) return;
    setLoading(true);
    try {
      // Check server-side approval gating first
      try {
        const check = await projectRequestService.getCanApprove(requestId);
        if (!check.canApprove) {
          toast.error(check.message || "Cannot approve yet. Ensure all reviewers submitted and minimum score met.");
          setLoading(false);
          return;
        }
      } catch {
        // proceed; server will enforce anyway
      }
      await projectRequestService.approveRequest(requestId, "Approved by Head");
      await projectRequestService.startExecution(requestId);
      toast.success("Request approved and moved to project execution");
      navigate(`/dashboard/${currentRole}/requests`);
    } catch (e: any) {
      toast.error(e?.message || "Failed to approve request");
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async () => {
    if (!requestId) return;
    setLoading(true);
    try {
      await projectRequestService.rejectRequest(requestId, "Rejected by Head", "Insufficient evaluation");
      toast.success("Request rejected");
      navigate(`/dashboard/${currentRole}/requests`);
    } catch (e: any) {
      toast.error(e?.message || "Failed to reject request");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button onClick={() => navigate(-1)} className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <ChevronLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-teal-900">Head Review Console</h1>
                <p className="text-gray-600 text-sm">Assign reviewers for Initial Evaluation and Idea Refinement, then approve/reject</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8 space-y-8">
        {/* Initial Evaluation */}
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center">
            <Users className="w-5 h-5 text-teal-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Initial Evaluation</h2>
          </div>
          <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            {initialEvaluationRoles.map((rn) => (
              <div key={rn} className="p-4 rounded-lg border border-gray-200 bg-gray-50">
                <div className="text-sm font-medium text-gray-800 mb-2">{rn}</div>
                <div className="flex items-center space-x-3">
                  <input
                    type="text"
                    placeholder="username or email"
                    value={assignInputsInitial[rn] || ""}
                    onChange={(e) => setAssignInputsInitial((p) => ({ ...p, [rn]: e.target.value }))}
                    className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                  <button
                    disabled={!assignInputsInitial[rn] || loading}
                    onClick={() => handleAssign("initial", rn, assignInputsInitial[rn])}
                    className="inline-flex items-center px-3 py-2 rounded-lg bg-teal-600 text-white text-xs font-medium shadow-sm hover:bg-teal-500 disabled:opacity-50"
                  >
                    <UserPlus className="w-4 h-4 mr-1" /> Assign
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Refinement */}
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200 flex items-center">
            <ClipboardList className="w-5 h-5 text-teal-600 mr-2" />
            <h2 className="text-lg font-semibold text-gray-900">Idea Refinement & Prioritisation</h2>
          </div>
          <div className="p-6">
            {!initialAllDone && (
              <div className="mb-4 px-4 py-3 rounded-lg border border-amber-200 bg-amber-50 text-amber-800 text-sm">
                Complete all Initial Evaluation tasks before assigning refinement reviewers.
              </div>
            )}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {refinementRoles.map((rn) => (
                <div key={rn} className="p-4 rounded-lg border border-gray-200 bg-gray-50">
                  <div className="text-sm font-medium text-gray-800 mb-2">{rn}</div>
                  <div className="flex items-center space-x-3">
                    <input
                      type="text"
                      placeholder="username or email"
                      value={assignInputsRefine[rn] || ""}
                      onChange={(e) => setAssignInputsRefine((p) => ({ ...p, [rn]: e.target.value }))}
                      disabled={!initialAllDone}
                      className={`flex-1 border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${
                        initialAllDone ? "border-gray-300 focus:ring-teal-500" : "border-gray-200 bg-gray-100 text-gray-400"
                      }`}
                    />
                    <button
                      disabled={!assignInputsRefine[rn] || loading || !initialAllDone}
                      onClick={() => handleAssign("refinement", rn, assignInputsRefine[rn])}
                      className="inline-flex items-center px-3 py-2 rounded-lg bg-teal-600 text-white text-xs font-medium shadow-sm hover:bg-teal-500 disabled:opacity-50"
                    >
                      <UserPlus className="w-4 h-4 mr-1" /> Assign
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Status and Actions */}
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Reviewer Responses</h2>
          </div>
          <div className="p-6">
            {tasks.length === 0 ? (
              <p className="text-sm text-gray-600">No tasks yet. Assign reviewers above to generate tasks.</p>
            ) : (
              <ul className="divide-y divide-gray-200">
                {tasks.map((t, idx) => (
                  <li key={idx} className="py-3 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium text-gray-800">{t?.title || t?.name || "Task"}</div>
                      <div className="text-xs text-gray-500">{t?.assignee || t?.assignedTo || ""}</div>
                    </div>
                    <div className="flex items-center text-sm">
                      {isTaskComplete(t) ? (
                        <span className="inline-flex items-center text-green-700">
                          <CheckCircle className="w-4 h-4 mr-1" /> Completed
                        </span>
                      ) : (
                        <span className="inline-flex items-center text-amber-700">
                          <XCircle className="w-4 h-4 mr-1" /> Pending
                        </span>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}

            <div className="mt-6 flex items-center justify-end space-x-3">
              <button
                onClick={handleReject}
                disabled={loading}
                className="px-5 py-2 rounded-lg border border-red-300 text-red-700 hover:bg-red-50"
              >
                Reject
              </button>
              <button
                onClick={handleApprove}
                disabled={!allResponsesReceived || loading}
                className={`px-5 py-2 rounded-lg text-white ${allResponsesReceived ? "bg-teal-600 hover:bg-teal-500" : "bg-teal-300"}`}
              >
                Approve & Move to Project
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeadReviewConsole;
