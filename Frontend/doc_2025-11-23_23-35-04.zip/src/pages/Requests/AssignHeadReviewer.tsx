import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ChevronLeft, UserPlus, ShieldCheck, Send } from "lucide-react";
import { toast } from "react-hot-toast";
import { projectRequestService, ProjectRequestSummary } from "@/services/projectRequestService";
import { useAuth } from "@/context/AuthContext";

const PENDING_STATUSES = ["Submitted", "Under Evaluation", "New", "Pending", "Backlogged"];

const AssignHeadReviewer: React.FC = () => {
  const navigate = useNavigate();
  const { role, id } = useParams<{ role: string; id?: string }>();
  const { user } = useAuth();

  const [requests, setRequests] = React.useState<ProjectRequestSummary[]>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);

  const [selectedRequestId, setSelectedRequestId] = React.useState<number | null>(id ? Number(id) : null);
  const [assignUsername, setAssignUsername] = React.useState<string>("");
  const [submitting, setSubmitting] = React.useState<boolean>(false);

  React.useEffect(() => {
    let mounted = true;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await projectRequestService.getAll();
        if (!mounted) return;
        const pending = data.filter((r) => PENDING_STATUSES.some((s) => r.status?.toLowerCase() === s.toLowerCase()));
        setRequests(pending);
        if (!selectedRequestId && id) setSelectedRequestId(Number(id));
      } catch (e: any) {
        if (!mounted) return;
        setError(e.message || "Failed to load requests");
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => {
      mounted = false;
    };
  }, [id, selectedRequestId]);

  const currentRole = role || "member";

  const selectedRequest = React.useMemo(() => requests.find((r) => r.id === selectedRequestId) || null, [requests, selectedRequestId]);

  const handleSelfAssign = async () => {
    if (!selectedRequestId) {
      toast.error("Please select a request first");
      return;
    }
    if (!user) {
      toast.error("You are not authenticated. Please log in again.");
      navigate("/login");
      return;
    }

    const payload = (user.username || user.id)
      ? { headUsername: user.username || undefined, headUserId: user.id || undefined, notify: true }
      : null;

    if (!payload) {
      toast.error("Cannot determine your user identity to assign as head.");
      return;
    }

    setSubmitting(true);
    try {
      await projectRequestService.assignHeadReviewer(selectedRequestId, payload as any);
      toast.success("You are assigned as Head Reviewer for this request.");
      navigate(`/dashboard/${currentRole}/requests`);
    } catch (e: any) {
      toast.error(e.message || "Failed to assign head reviewer");
    } finally {
      setSubmitting(false);
    }
  };

  const handleAssignOther = async () => {
    if (!selectedRequestId || !assignUsername) return;
    try {
      await projectRequestService.assignHeadReviewer(selectedRequestId, {
        headUsername: assignUsername,
        notify: true,
      });
      toast.success(`Assigned ${assignUsername} as Head Reviewer.`);
      navigate(`/dashboard/${currentRole}/requests`);
    } catch (e: any) {
      toast.error(e.message || "Failed to assign head reviewer");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button onClick={() => navigate(-1)} className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <ChevronLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-teal-900">Assign Head Reviewer</h1>
                <p className="text-gray-600 text-sm">Appoint the owner responsible for evaluation and final decision</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-semibold text-teal-900">Commercial Bank of Ethiopia</div>
              <div className="text-sm font-medium text-teal-700">Digital Factory</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="px-6 py-5 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Select Request</h2>
          </div>
          <div className="p-6 space-y-6">
            {error && <div className="p-3 rounded border border-red-200 bg-red-50 text-sm text-red-700">{error}</div>}
            {loading ? (
              <div className="text-sm text-gray-600">Loading requests...</div>
            ) : (
              <div>
                <select
                  className="w-full md:w-1/2 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  value={selectedRequestId ?? ""}
                  onChange={(e) => setSelectedRequestId(e.target.value ? Number(e.target.value) : null)}
                >
                  <option value="">Select a request...</option>
                  {requests.map((r) => (
                    <option key={r.id} value={r.id}>
                      #{r.requestID} — {r.requestTitle}
                    </option>
                  ))}
                </select>
                {selectedRequest && (
                  <p className="mt-2 text-sm text-gray-600">{selectedRequest.requestDescription || "No description"}</p>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 rounded-lg border border-gray-200 bg-gray-50">
                <div className="flex items-center mb-3">
                  <ShieldCheck className="w-5 h-5 text-teal-600 mr-2" />
                  <h3 className="font-semibold text-gray-900">Assign Myself</h3>
                </div>
                <p className="text-sm text-gray-600 mb-4">You will be responsible for reviewer assignments, tracking, and final decision.</p>
                <button
                  disabled={!selectedRequestId || submitting}
                  onClick={handleSelfAssign}
                  className="inline-flex items-center px-4 py-2 rounded-lg bg-teal-600 text-white text-sm font-medium shadow-sm hover:bg-teal-500 disabled:opacity-50"
                >
                  <UserPlus className="w-4 h-4 mr-2" />
                  {submitting ? "Assigning..." : "Assign Me as Head"}
                </button>
              </div>

              <div className="p-4 rounded-lg border border-gray-200 bg-gray-50">
                <div className="flex items-center mb-3">
                  <UserPlus className="w-5 h-5 text-teal-600 mr-2" />
                  <h3 className="font-semibold text-gray-900">Assign Someone Else</h3>
                </div>
                <div className="flex items-center space-x-3">
                  <input
                    type="text"
                    value={assignUsername}
                    onChange={(e) => setAssignUsername(e.target.value)}
                    placeholder="Enter username or email"
                    className="flex-1 border border-gray-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                  <button
                    disabled={!selectedRequestId || !assignUsername}
                    onClick={handleAssignOther}
                    className="inline-flex items-center px-4 py-2 rounded-lg bg-teal-600 text-white text-sm font-medium shadow-sm hover:bg-teal-500 disabled:opacity-50"
                  >
                    <Send className="w-4 h-4 mr-2" />
                    Assign
                  </button>
                </div>
                <p className="text-xs text-gray-500 mt-2">They will receive a notification and see this under their head assignments.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssignHeadReviewer;
