import React from "react";
import { useNavigate, useParams } from "react-router-dom";
import { ChevronLeft, Users, Calendar, ClipboardList, Send } from "lucide-react";
import { toast } from "react-hot-toast";
import { projectRequestService, ProjectRequestSummary } from "@/services/projectRequestService";
import { useAuth } from "@/context/AuthContext";

const PENDING_STATUSES = ["Submitted", "Under Evaluation", "New", "Pending", "Backlogged"]; 

const AssignReviewers: React.FC<{ darkMode?: boolean }> = ({ darkMode = false }) => {
  const navigate = useNavigate();
  const { role, id } = useParams<{ role: string; id?: string }>();
  const { user } = useAuth();

  const [requests, setRequests] = React.useState<ProjectRequestSummary[]>([]);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  const [selectedRequestId, setSelectedRequestId] = React.useState<number | null>(id ? parseInt(id) : null);

  // Team assignment state
  const [assignBA, setAssignBA] = React.useState(true);
  const [baPrimary, setBaPrimary] = React.useState("");
  const [baTask, setBaTask] = React.useState("Document business requirements");

  const [assignInnovation, setAssignInnovation] = React.useState(true);
  const [innovationPrimary, setInnovationPrimary] = React.useState("");
  const [innovationTask, setInnovationTask] = React.useState("Provide innovative approaches");

  const [assignStakeholders, setAssignStakeholders] = React.useState(true);
  const [stakeholderMembers, setStakeholderMembers] = React.useState<string>("");
  const [stakeholderTask, setStakeholderTask] = React.useState("Provide business input & feedback");

  const [dueDate, setDueDate] = React.useState<string>("");
  const [criteria, setCriteria] = React.useState({ strategic: true, feasibility: true, business: true, technical: true });
  const [instructions, setInstructions] = React.useState<string>("");
  const [submitting, setSubmitting] = React.useState(false);

  const resolvedRole = (user?.role || role || "").toLowerCase();
  const isPrivileged = resolvedRole === "vice_president" || resolvedRole === "director";

  React.useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        setLoading(true);
        setError(null);
        const data = await projectRequestService.getAll();
        if (!mounted) return;
        const pending = data.filter((r) => PENDING_STATUSES.some((s) => r.status?.toLowerCase() === s.toLowerCase()));
        setRequests(pending);
        if (!selectedRequestId && pending.length > 0 && !id) {
          setSelectedRequestId(pending[0].id);
        }
      } catch (e: any) {
        if (!mounted) return;
        setError(e.message || "Failed to load requests");
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();
    return () => { mounted = false; };
  }, [id]);

  const goBack = () => {
    navigate(`/dashboard/${resolvedRole}/requests`);
  };

  const handleAssign = async () => {
    if (!isPrivileged) {
      toast.error("Only Vice President or Director can assign reviewers.");
      return;
    }
    if (!selectedRequestId) {
      toast.error("Please select a request to assign.");
      return;
    }

    setSubmitting(true);
    try {
      // Assign BA primary
      if (assignBA && baPrimary) {
        await projectRequestService.assignReviewers(selectedRequestId, {
          assignedTeam: "Business Analyst Team",
          assignedTo: baPrimary,
          assigneeRole: "business_analyst",
          setAsPrimary: true,
          reviewerType: "Primary",
        });
      }
      // Assign Innovation primary
      if (assignInnovation && innovationPrimary) {
        await projectRequestService.assignReviewers(selectedRequestId, {
          assignedTeam: "Innovation Chapter",
          assignedTo: innovationPrimary,
          assigneeRole: "innovation",
          setAsPrimary: true,
          reviewerType: "Primary",
        });
      }
      // Assign Stakeholders (comma-separated list)
      if (assignStakeholders && stakeholderMembers.trim()) {
        const members = stakeholderMembers.split(",").map((s) => s.trim()).filter(Boolean);
        for (const m of members) {
          await projectRequestService.assignReviewers(selectedRequestId, {
            assignedTeam: "Stakeholders",
            assignedTo: m,
            assigneeRole: "stakeholder",
            setAsPrimary: false,
            reviewerType: "Member",
          });
        }
      }

      toast.success("Reviewers assigned and notified.");
      navigate(`/dashboard/${resolvedRole}/requests/${selectedRequestId}`);
    } catch (e: any) {
      toast.error(e.message || "Failed to assign reviewers");
    } finally {
      setSubmitting(false);
    }
  };

  if (!isPrivileged) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white border border-gray-200 rounded-xl p-8 text-center">
          <div className="text-teal-700 font-semibold mb-2">Access Restricted</div>
          <p className="text-gray-600">Only Vice President and Director can assign reviewers.</p>
          <button onClick={goBack} className="mt-4 inline-flex items-center px-4 py-2 rounded-lg bg-teal-600 text-white hover:bg-teal-500">
            <ChevronLeft className="w-4 h-4 mr-2" /> Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button onClick={goBack} className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors">
                <ChevronLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-teal-900">Assign Reviewers & Set Tasks</h1>
                <p className="text-gray-600 text-sm">Configure multi-role evaluation for the selected request</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-semibold text-teal-900">Commercial Bank of Ethiopia</div>
              <div className="text-sm font-medium text-teal-700">Digital Factory</div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Request Picker */}
        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
            <ClipboardList className="w-5 h-5 mr-2 text-gray-600" />
            Request Selection
          </h2>
          {loading ? (
            <div className="flex items-center text-gray-600">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-teal-600 mr-3"></div>
              Loading requests...
            </div>
          ) : error ? (
            <div className="text-red-600">{error}</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Request</label>
                <select
                  value={selectedRequestId ?? ""}
                  onChange={(e) => setSelectedRequestId(e.target.value ? parseInt(e.target.value) : null)}
                  className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition"
                >
                  <option value="">Select a request</option>
                  {requests.map((r) => (
                    <option key={r.id} value={r.id}>
                      #{r.requestID || r.id} — {r.requestTitle}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                <div className="relative">
                  <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
                  <Calendar className="w-4 h-4 text-gray-500 absolute right-3 top-1/2 -translate-y-1/2" />
                </div>
                <p className="text-xs text-gray-500 mt-1">Optional, for communication in notifications.</p>
              </div>
            </div>
          )}
        </div>

        {/* Evaluation Parameters */}
        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 mb-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200">Evaluation Parameters</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Criteria</label>
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={criteria.strategic} onChange={(e) => setCriteria((c) => ({ ...c, strategic: e.target.checked }))} /> Strategic Alignment</label>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={criteria.feasibility} onChange={(e) => setCriteria((c) => ({ ...c, feasibility: e.target.checked }))} /> Feasibility</label>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={criteria.business} onChange={(e) => setCriteria((c) => ({ ...c, business: e.target.checked }))} /> Business Value</label>
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={criteria.technical} onChange={(e) => setCriteria((c) => ({ ...c, technical: e.target.checked }))} /> Technical Complexity</label>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Instructions</label>
              <textarea value={instructions} onChange={(e) => setInstructions(e.target.value)} rows={3} placeholder="Provide any guidance for reviewers..." className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition resize-none" />
            </div>
          </div>
        </div>

        {/* Teams */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center"><Users className="w-4 h-4 text-teal-600 mr-2" /> Business Analyst Team</h3>
            <label className="flex items-center gap-2 text-sm mb-3"><input type="checkbox" checked={assignBA} onChange={(e) => setAssignBA(e.target.checked)} /> Assign BA Team</label>
            <label className="block text-sm font-medium text-gray-700 mb-1">Primary</label>
            <input value={baPrimary} onChange={(e) => setBaPrimary(e.target.value)} placeholder="Enter username or AD ID" className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
            <label className="block text-sm font-medium text-gray-700 mt-4 mb-1">Task</label>
            <input value={baTask} onChange={(e) => setBaTask(e.target.value)} className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
          </div>

          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center"><Users className="w-4 h-4 text-teal-600 mr-2" /> Innovation Chapter</h3>
            <label className="flex items-center gap-2 text-sm mb-3"><input type="checkbox" checked={assignInnovation} onChange={(e) => setAssignInnovation(e.target.checked)} /> Assign Innovation Chapter</label>
            <label className="block text-sm font-medium text-gray-700 mb-1">Primary</label>
            <input value={innovationPrimary} onChange={(e) => setInnovationPrimary(e.target.value)} placeholder="Enter username or AD ID" className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
            <label className="block text-sm font-medium text-gray-700 mt-4 mb-1">Task</label>
            <input value={innovationTask} onChange={(e) => setInnovationTask(e.target.value)} className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
          </div>

          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-base font-semibold text-gray-900 mb-4 flex items-center"><Users className="w-4 h-4 text-teal-600 mr-2" /> Stakeholders</h3>
            <label className="flex items-center gap-2 text-sm mb-3"><input type="checkbox" checked={assignStakeholders} onChange={(e) => setAssignStakeholders(e.target.checked)} /> Include Stakeholders</label>
            <label className="block text-sm font-medium text-gray-700 mb-1">Members</label>
            <input value={stakeholderMembers} onChange={(e) => setStakeholderMembers(e.target.value)} placeholder="Comma-separated usernames" className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
            <label className="block text-sm font-medium text-gray-700 mt-4 mb-1">Task</label>
            <input value={stakeholderTask} onChange={(e) => setStakeholderTask(e.target.value)} className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition" />
          </div>
        </div>

        <div className="flex items-center justify-between">
          <button onClick={goBack} className="inline-flex items-center px-4 py-2 rounded-lg border border-gray-300 bg-white text-gray-700 hover:bg-gray-50">
            <ChevronLeft className="w-4 h-4 mr-2" /> Back
          </button>
          <button onClick={handleAssign} disabled={submitting} className={`inline-flex items-center px-5 py-2 rounded-lg text-white bg-teal-600 hover:bg-teal-500 ${submitting ? "opacity-60 cursor-not-allowed" : ""}`}>
            {submitting ? (
              <span className="flex items-center"><div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div> Assigning...</span>
            ) : (
              <>
                <Send className="w-4 h-4 mr-2" /> Assign & Notify
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AssignReviewers;
