import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, User, Building2, Mail, Phone, DollarSign, TrendingUp, Clock, AlertCircle, CheckCircle, XCircle, FileText } from 'lucide-react';
import { getProjectRequestById, type ProjectRequestDetailDto } from '@/services/requestService';
import { projectRequestService } from '@/services/projectRequestService';

const RequestDetail: React.FC<{ darkMode?: boolean }> = ({ darkMode = false }) => {
  const navigate = useNavigate();
  const { role, id } = useParams<{ role: string; id: string }>();
  const [request, setRequest] = useState<ProjectRequestDetailDto | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isHead, setIsHead] = useState<boolean>(false);
  const [ownerHistory, setOwnerHistory] = useState<any[] | null>(null);

  useEffect(() => {
    const fetchRequest = async () => {
      if (!id) {
        setError('Request ID is required');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        setError(null);
        const data = await getProjectRequestById(parseInt(id));
        setRequest(data);
        // Determine if current user is head for this request
        try {
          const myHeadIds = await projectRequestService.getHeadAssignmentsForCurrentUser();
          setIsHead(Array.isArray(myHeadIds) && myHeadIds.includes(parseInt(id)));
        } catch (e) {
          setIsHead(false);
        }
        // Load owner history for display
        try {
          const hist = await projectRequestService.getOwnerHistory(parseInt(id));
          setOwnerHistory(Array.isArray(hist) ? hist : []);
        } catch (e) {
          setOwnerHistory(null);
        }
      } catch (err: any) {
        console.error('Failed to fetch request:', err);
        setError(err.message || 'Failed to load request details');
      } finally {
        setLoading(false);
      }
    };

    fetchRequest();
  }, [id]);

  const handleBack = () => {
    navigate(`/dashboard/${role}/requests`);
  };

  const getStatusBadgeClass = (statusName: string) => {
    const statusColors: Record<string, string> = {
      'Submitted': 'bg-blue-100 text-blue-800 border-blue-200',
      'Under Evaluation': 'bg-yellow-100 text-yellow-800 border-yellow-200',
      'Approved': 'bg-green-100 text-green-800 border-green-200',
      'Rejected': 'bg-red-100 text-red-800 border-red-200',
      'Backlogged': 'bg-gray-100 text-gray-800 border-gray-200',
      'In Progress': 'bg-purple-100 text-purple-800 border-purple-200',
      'Completed': 'bg-green-100 text-green-800 border-green-200',
      'Delivered': 'bg-emerald-100 text-emerald-800 border-emerald-200',
      'Closed': 'bg-gray-100 text-gray-800 border-gray-200',
    };
    return statusColors[statusName] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-purple-900 mb-4"></div>
          <p className="text-gray-600">Loading request details...</p>
        </div>
      </div>
    );
  }

  if (error || !request) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="bg-red-50 border border-red-200 rounded-lg p-6">
            <div className="flex items-center">
              <XCircle className="w-6 h-6 text-red-600 mr-3" />
              <div>
                <h3 className="text-lg font-semibold text-red-800">Error Loading Request</h3>
                <p className="text-sm text-red-600 mt-1">{error || 'Request not found'}</p>
              </div>
            </div>
            <button
              onClick={handleBack}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Back to Requests
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - matching RequestForm style */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={handleBack}
                className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-teal-900">
                  Request Details
                </h1>
                <p className="text-gray-600 text-sm">View complete request information</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-semibold text-teal-900">
                Commercial Bank of Ethiopia
              </div>
              <div className="text-sm font-medium text-teal-700">
                Digital Factory
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Request ID and Status Banner */}
        <div className="mb-6 bg-white rounded-lg border border-gray-300 shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center space-x-4">
                <div>
                  <span className="text-sm font-medium text-gray-600">Request ID</span>
                  <div className="text-2xl font-mono font-bold text-purple-900 mt-1">
                    {request.requestID || `PR-${request.id}`}
                  </div>
                </div>
                {request.referenceNo && (
                  <div className="pl-4 border-l border-gray-300">
                    <span className="text-sm font-medium text-gray-600">Reference No</span>
                    <div className="text-lg font-semibold text-gray-900 mt-1">
                      {request.referenceNo}
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="text-right">
              <span className="text-sm font-medium text-gray-600 block mb-2">Status</span>
              <span className={`px-4 py-2 rounded-lg text-sm font-semibold border ${getStatusBadgeClass(request.status.name)}`}>
                {request.status.name}
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content - Left Column (2/3) */}
          <div className="lg:col-span-2 space-y-6">
            {/* Core Information */}
            <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                <FileText className="w-5 h-5 mr-2 text-gray-600" />
                Core Information
              </h2>
              <div className="space-y-4">
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Request Title</span>
                  <p className="text-gray-900 text-base font-medium">{request.requestTitle}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Description</span>
                  <p className="text-gray-900 text-base whitespace-pre-wrap">{request.requestDescription}</p>
                </div>
              </div>
            </div>

            {/* Classification */}
            <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                <AlertCircle className="w-5 h-5 mr-2 text-gray-600" />
                Classification & Categorization
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Request Type</span>
                  <p className="text-gray-900">{request.requestType.name || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Request Category</span>
                  <p className="text-gray-900">{request.requestCategory.name || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Service Category</span>
                  <p className="text-gray-900">{request.serviceCategory.name || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Product Category</span>
                  <p className="text-gray-900">{request.productCategory.name || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Business Impact</span>
                  <p className="text-gray-900">{request.businessImpact.name || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Request Urgency</span>
                  <p className="text-gray-900">{request.requestUrgency.name || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Priority Level</span>
                  <span
                    className="inline-block px-3 py-1 rounded text-sm font-semibold"
                    style={{
                      backgroundColor: request.priority.color 
                        ? `${request.priority.color}20` 
                        : '#f3f4f620',
                      color: request.priority.color || '#6b7280',
                      border: `1px solid ${request.priority.color || '#e5e7eb'}`,
                    }}
                  >
                    {request.priority.name || '—'}
                  </span>
                </div>
                {request.riskLevel && (
                  <div>
                    <span className="text-sm font-medium text-gray-600 block mb-1">Risk Level</span>
                    <p className="text-gray-900">{request.riskLevel.name || '—'}</p>
                  </div>
                )}
                {request.complexityLevel && (
                  <div>
                    <span className="text-sm font-medium text-gray-600 block mb-1">Complexity Level</span>
                    <p className="text-gray-900">{request.complexityLevel.name || '—'}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Metadata */}
            <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-gray-600" />
                Additional Metadata
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Strategic Alignment</span>
                  <p className="text-gray-900">{request.strategicAlignment || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Requested Delivery Date</span>
                  <p className="text-gray-900">
                    {request.requestedDeliveryDate 
                      ? new Date(request.requestedDeliveryDate).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })
                      : '—'}
                  </p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Estimated Cost (ETB)</span>
                  <p className="text-gray-900">
                    {request.estimatedCost 
                      ? new Intl.NumberFormat('en-ET', { 
                          style: 'currency', 
                          currency: 'ETB' 
                        }).format(request.estimatedCost)
                      : '—'}
                  </p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Estimated Benefit (ETB)</span>
                  <p className="text-gray-900">
                    {request.estimatedBenefit 
                      ? new Intl.NumberFormat('en-ET', { 
                          style: 'currency', 
                          currency: 'ETB' 
                        }).format(request.estimatedBenefit)
                      : '—'}
                  </p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Benefit Capture Duration</span>
                  <p className="text-gray-900">
                    {request.benefitCaptureDuration 
                      ? `${request.benefitCaptureDuration} month${request.benefitCaptureDuration !== 1 ? 's' : ''}`
                      : '—'}
                  </p>
                </div>
              </div>
            </div>

            {/* Evaluation Scores */}
            {(request.totalScore !== null && request.totalScore !== undefined) || 
             request.feasibilityScore || request.businessValueScore || request.technicalComplexityScore ? (
              <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2 text-gray-600" />
                  Evaluation Scores
                </h2>
                <div className="grid grid-cols-2 gap-4">
                  {request.feasibilityScore !== null && request.feasibilityScore !== undefined && (
                    <div>
                      <span className="text-sm font-medium text-gray-600 block mb-1">Feasibility Score</span>
                      <p className="text-gray-900 text-lg font-semibold">{request.feasibilityScore}</p>
                    </div>
                  )}
                  {request.businessValueScore !== null && request.businessValueScore !== undefined && (
                    <div>
                      <span className="text-sm font-medium text-gray-600 block mb-1">Business Value Score</span>
                      <p className="text-gray-900 text-lg font-semibold">{request.businessValueScore}</p>
                    </div>
                  )}
                  {request.technicalComplexityScore !== null && request.technicalComplexityScore !== undefined && (
                    <div>
                      <span className="text-sm font-medium text-gray-600 block mb-1">Technical Complexity Score</span>
                      <p className="text-gray-900 text-lg font-semibold">{request.technicalComplexityScore}</p>
                    </div>
                  )}
                  {request.totalScore !== null && request.totalScore !== undefined && (
                    <div>
                      <span className="text-sm font-medium text-gray-600 block mb-1">Total Score</span>
                      <p className="text-gray-900 text-2xl font-bold text-purple-900">{request.totalScore.toFixed(1)}</p>
                    </div>
                  )}
                  {request.evaluationRemarks && (
                    <div className="col-span-2">
                      <span className="text-sm font-medium text-gray-600 block mb-1">Evaluation Remarks</span>
                      <p className="text-gray-900 whitespace-pre-wrap">{request.evaluationRemarks}</p>
                    </div>
                  )}
                </div>
              </div>
            ) : null}
          </div>

          {/* Sidebar - Right Column (1/3) */}
          <div className="space-y-6">
            {/* Requestor Details */}
            <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                <User className="w-5 h-5 mr-2 text-gray-600" />
                Requestor Details
              </h2>
              <div className="space-y-4">
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Requested By (AD User ID)</span>
                  <p className="text-gray-900">{request.requestedBy || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Requested By Name</span>
                  <p className="text-gray-900">{request.requestedByName || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Organization</span>
                  <p className="text-gray-900">{request.organizationName || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Business Sector</span>
                  <p className="text-gray-900">{request.businessSector || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Business Division</span>
                  <p className="text-gray-900">{request.businessDivision || '—'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600 block mb-1">Business Department</span>
                  <p className="text-gray-900">{request.businessDepartment || '—'}</p>
                </div>
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex items-center mb-2">
                    <Mail className="w-4 h-4 text-gray-500 mr-2" />
                    <span className="text-sm font-medium text-gray-600">Primary Email</span>
                  </div>
                  <p className="text-gray-900 ml-6">{request.primaryContactEmail || '—'}</p>
                </div>
                {request.secondaryContactEmail && (
                  <div>
                    <div className="flex items-center mb-2">
                      <Mail className="w-4 h-4 text-gray-500 mr-2" />
                      <span className="text-sm font-medium text-gray-600">Secondary Email</span>
                    </div>
                    <p className="text-gray-900 ml-6">{request.secondaryContactEmail}</p>
                  </div>
                )}
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex items-center mb-2">
                    <Phone className="w-4 h-4 text-gray-500 mr-2" />
                    <span className="text-sm font-medium text-gray-600">Primary Phone</span>
                  </div>
                  <p className="text-gray-900 ml-6">{request.primaryContactPhone || '—'}</p>
                </div>
                {request.secondaryContactPhone && (
                  <div>
                    <div className="flex items-center mb-2">
                      <Phone className="w-4 h-4 text-gray-500 mr-2" />
                      <span className="text-sm font-medium text-gray-600">Secondary Phone</span>
                    </div>
                    <p className="text-gray-900 ml-6">{request.secondaryContactPhone}</p>
                  </div>
                )}
              </div>
            </div>

                {/* Workflow & Assignment (expanded) */}
                <div className="bg-white rounded-lg border border-gray-300 shadow-sm p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                    <Building2 className="w-5 h-5 mr-2 text-gray-600" />
                    Workflow & Assignment
                  </h2>
                  <div className="space-y-4">
                    {request.workflowStage && (
                      <div>
                        <span className="text-sm font-medium text-gray-600 block mb-1">Workflow Stage</span>
                        <p className="text-gray-900">{request.workflowStage.name || '—'}</p>
                      </div>
                    )}
                    {request.assignedTeam && (
                      <div>
                        <span className="text-sm font-medium text-gray-600 block mb-1">Assigned Team</span>
                        <p className="text-gray-900">{request.assignedTeam}</p>
                      </div>
                    )}

                    {/* Show explicit Head reviewer information (owner history preferred, fallback to assignedTo) */}
                    <div>
                      <span className="text-sm font-medium text-gray-600 block mb-1">Head Reviewer</span>
                      <p className="text-gray-900">
                        {(() => {
                          // Prefer ownerHistory latest active Head role entry
                          if (ownerHistory && ownerHistory.length > 0) {
                            const activeHead = ownerHistory.find((h: any) => (h.ownerRole || h.OwnerRole || '').toLowerCase().includes('head') && (h.status || h.Status || '').toLowerCase() === 'active');
                            if (activeHead) return activeHead.ownerName || activeHead.OwnerName || activeHead.ownerId || activeHead.OwnerID || request.assignedTo || '—';
                            // otherwise display most recent head entry
                            const recentHead = ownerHistory.slice().reverse().find((h: any) => (h.ownerRole || h.OwnerRole || '').toLowerCase().includes('head'));
                            if (recentHead) return recentHead.ownerName || recentHead.OwnerName || recentHead.ownerId || recentHead.OwnerID || request.assignedTo || '—';
                          }
                          return request.assignedTo || '—';
                        })()}
                      </p>
                    </div>

                    {request.assignedTo && (
                      <div>
                        <span className="text-sm font-medium text-gray-600 block mb-1">Assigned To</span>
                        <p className="text-gray-900">{request.assignedTo}</p>
                      </div>
                    )}
                    {request.evaluatorID && (
                      <div>
                        <span className="text-sm font-medium text-gray-600 block mb-1">Evaluator ID</span>
                        <p className="text-gray-900">{request.evaluatorID}</p>
                      </div>
                    )}

                    {/* If current user is head, expose quick action to go to initial evaluation */}
                    {isHead && (
                      <div className="pt-3 border-t border-gray-200">
                        <button
                          onClick={() => navigate(`/dashboard/${role}/requests/${id}/head`)}
                          className="w-full inline-flex items-center justify-center px-4 py-2 rounded-lg bg-teal-600 text-white text-sm font-medium shadow-sm hover:bg-teal-500"
                        >
                          Go to Initial Evaluation
                        </button>
                      </div>
                    )}
                  </div>
                </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestDetail;

