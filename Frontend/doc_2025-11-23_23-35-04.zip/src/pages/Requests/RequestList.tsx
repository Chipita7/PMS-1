import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Plus, RefreshCw, FileText, ChevronLeft } from 'lucide-react';
import DataTables from '@/components/DataTables';
import { getAllProjectRequests, type ProjectRequestDto } from '@/services/requestService';

const RequestList: React.FC<{ darkMode?: boolean }> = ({ darkMode = false }) => {
  const navigate = useNavigate();
  const { role } = useParams<{ role: string }>();
  const [requests, setRequests] = useState<ProjectRequestDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const handleBack = () => {
    navigate(`/dashboard/${role}`);
  };

  const fetchRequests = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await getAllProjectRequests();
      setRequests(data);
    } catch (err: any) {
      console.error('Failed to fetch requests:', err);
      // Provide user-friendly error message
      const errorMessage = err.message || 'Failed to load requests';
      setError(
        errorMessage.includes('Cannot connect') || errorMessage.includes('Network error')
          ? 'Backend server is not reachable. Please ensure the backend is running on http://localhost:8080'
          : errorMessage
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, []);

  const handleNewRequest = () => {
    navigate(`/dashboard/${role}/requests/new`);
  };

  const handleRowClick = (row: ProjectRequestDto) => {
    navigate(`/dashboard/${role}/requests/${row.id}`);
  };

  // Request-specific columns
  const requestColumns = (darkMode: boolean) => [
    {
      name: "Request ID",
      selector: (row: ProjectRequestDto) => row.requestID || `PR-${row.id}`,
      sortable: true,
      minWidth: "140px",
      cell: (row: ProjectRequestDto) => (
        <div className="font-mono text-sm font-semibold text-purple-900">
          {row.requestID || `PR-${row.id}`}
        </div>
      ),
    },
    {
      name: "Title",
      selector: (row: ProjectRequestDto) => row.requestTitle,
      sortable: true,
      minWidth: "250px",
      cell: (row: ProjectRequestDto) => (
        <div>
          <div className="font-medium text-gray-900">{row.requestTitle}</div>
          {row.requestDescription && (
            <div className={`text-sm mt-1 ${darkMode ? "text-gray-400" : "text-gray-500"} line-clamp-2`}>
              {row.requestDescription.length > 100 
                ? `${row.requestDescription.substring(0, 100)}...` 
                : row.requestDescription}
            </div>
          )}
        </div>
      ),
    },
    {
      name: "Request Type",
      selector: (row: ProjectRequestDto) => row.requestType,
      sortable: true,
      minWidth: "150px",
    },
    {
      name: "Priority",
      selector: (row: ProjectRequestDto) => row.priority,
      sortable: true,
      minWidth: "100px",
      cell: (row: ProjectRequestDto) => (
        <div className="flex items-center">
          <span
            className="px-2 py-1 rounded text-xs font-semibold"
            style={{
              backgroundColor: row.priorityColor 
                ? `${row.priorityColor}20` 
                : '#f3f4f620',
              color: row.priorityColor || '#6b7280',
              border: `1px solid ${row.priorityColor || '#e5e7eb'}`,
            }}
          >
            {row.priority || '—'}
          </span>
        </div>
      ),
    },
    {
      name: "Status",
      selector: (row: ProjectRequestDto) => row.status,
      sortable: true,
      minWidth: "120px",
      cell: (row: ProjectRequestDto) => {
        const statusColors: Record<string, string> = {
          'Submitted': 'bg-blue-100 text-blue-800 border-blue-200',
          'Under Evaluation': 'bg-yellow-100 text-yellow-800 border-yellow-200',
          'Approved': 'bg-green-100 text-green-800 border-green-200',
          'Rejected': 'bg-red-100 text-red-800 border-red-200',
          'Backlogged': 'bg-gray-100 text-gray-800 border-gray-200',
          'In Progress': 'bg-purple-100 text-purple-800 border-purple-200',
          'Completed': 'bg-green-100 text-green-800 border-green-200',
          'Delivered': 'bg-emerald-100 text-emerald-800 border-emerald-200',
          'Closed': 'bg-gray-100 text-gray-800 border-gray-200',
        };
        const statusClass = statusColors[row.status] || 'bg-gray-100 text-gray-800 border-gray-200';
        return (
          <span className={`px-2 py-1 rounded text-xs font-medium border ${statusClass}`}>
            {row.status || '—'}
          </span>
        );
      },
    },
    {
      name: "Requested By",
      selector: (row: ProjectRequestDto) => row.requestedByName,
      sortable: true,
      minWidth: "150px",
    },
    {
      name: "Department",
      selector: (row: ProjectRequestDto) => row.businessDepartment,
      sortable: true,
      minWidth: "150px",
    },
    {
      name: "Created Date",
      selector: (row: ProjectRequestDto) => row.createdDate,
      sortable: true,
      minWidth: "120px",
      cell: (row: ProjectRequestDto) => {
        if (!row.createdDate) return '—';
        const date = new Date(row.createdDate);
        return (
          <div className="text-sm">
            <div>{date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</div>
            <div className="text-gray-500 text-xs">{date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</div>
          </div>
        );
      },
    },
    {
      name: "Duration (Days)",
      selector: (row: ProjectRequestDto) => row.requestDurationDays,
      sortable: true,
      minWidth: "120px",
      cell: (row: ProjectRequestDto) => (
        <div className="text-sm">
          {row.requestDurationDays ? `${row.requestDurationDays} days` : '—'}
        </div>
      ),
    },
    {
      name: "Score",
      selector: (row: ProjectRequestDto) => row.totalScore || 0,
      sortable: true,
      minWidth: "100px",
      cell: (row: ProjectRequestDto) => (
        <div className="text-sm font-semibold">
          {row.totalScore ? row.totalScore.toFixed(1) : '—'}
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - matching RequestForm style */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={handleBack}
                className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-teal-900">Project Requests</h1>
                <p className="text-gray-600 text-sm">View and manage all project requests</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-semibold text-teal-900">
                Commercial Bank of Ethiopia
              </div>
              <div className="text-sm font-medium text-teal-700">
                Digital Factory
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Action Buttons */}
        <div className="mb-6 flex items-center justify-end space-x-3">
          <button
            onClick={fetchRequests}
            disabled={loading}
            className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${
              darkMode
                ? 'bg-gray-800 text-gray-200 hover:bg-gray-700 border border-gray-700'
                : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
            } ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>
          <button
            onClick={handleNewRequest}
            className="px-6 py-2 rounded-lg font-medium text-white bg-teal-600 hover:bg-teal-500 transition-all duration-200 shadow-sm hover:shadow-md flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>New Request</span>
          </button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center">
              <svg className="w-5 h-5 text-red-600 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <div>
                <p className="text-sm font-medium text-red-800">Error loading requests</p>
                <p className="text-sm text-red-600 mt-1">{error}</p>
              </div>
            </div>
          </div>
        )}

        {/* Data Table */}
        <div className={`rounded-lg border overflow-hidden ${
          darkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
        }`}>
          <DataTables
            data={requests}
            columns={requestColumns(darkMode)}
            onRowClicked={handleRowClick}
            darkMode={darkMode}
            loading={loading}
            pagination
            paginationPerPage={10}
            paginationRowsPerPageOptions={[5, 10, 15, 20, 25]}
            searchable={true}
            searchPlaceholder="Search requests by title, ID, type, or requester..."
            customizableColumns={true}
          />
        </div>

        {/* Empty State */}
        {!loading && !error && requests.length === 0 && (
          <div className="text-center py-12">
            <FileText className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className={`text-lg font-semibold mb-2 ${darkMode ? 'text-gray-300' : 'text-gray-900'}`}>
              No requests found
            </h3>
            <p className={`text-sm mb-6 ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              Get started by creating your first project request
            </p>
            <button
              onClick={handleNewRequest}
              className="px-6 py-3 rounded-lg font-medium text-white bg-teal-600 hover:bg-teal-500 transition-all duration-200 shadow-sm hover:shadow-md flex items-center space-x-2 mx-auto"
            >
              <Plus className="w-5 h-5" />
              <span>Create New Request</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default RequestList;

