import React from "react";
import { useNavigate, useParams, useLocation } from "react-router-dom";
import {
  projectRequestService,
  ProjectRequestSummary,
} from "@/services/projectRequestService";
import {
  Bell,
  FileText,
  BarChart2,
  CheckCircle,
  Clock,
  Plus,
  ArrowRight,
  Users,
  Eye,
  UserPlus,
  ShieldCheck,
  MoreVertical,
} from "lucide-react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import DataTables from "@/components/DataTables";

const RequestsDashboard: React.FC<{ darkMode?: boolean }> = ({ darkMode }) => {
  const { role } = useParams<{ role: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const resolvedRole = role || "member";

  const [requests, setRequests] = React.useState<ProjectRequestSummary[]>([]);
  const [filtered, setFiltered] = React.useState<ProjectRequestSummary[]>([]);
  const [loading, setLoading] = React.useState<boolean>(false);
  const [error, setError] = React.useState<string | null>(null);
  const [myHeadIds, setMyHeadIds] = React.useState<number[]>([]);
  const [viewFilter, setViewFilter] = React.useState<"all" | "mine">("all");
  const [openMenuId, setOpenMenuId] = React.useState<number | null>(null);

  // Load all requests
  React.useEffect(() => {
    let isMounted = true;
    const load = async () => {
      setLoading(true);
      setError(null);
      try {
        const data = await projectRequestService.getAll();
        if (isMounted) setRequests(data);
      } catch (e: any) {
        if (isMounted) setError(e.message || "Failed to load requests");
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    load();
    return () => {
      isMounted = false;
    };
  }, []);

  // Filter pending statuses
  React.useEffect(() => {
    const pendingStatuses = [
      "Submitted",
      "Under Evaluation",
      "New",
      "Pending",
      "Backlogged",
    ];
    const pending = requests.filter((r) =>
      pendingStatuses.some((s) => r.status?.toLowerCase() === s.toLowerCase())
    );
    setFiltered(pending);
  }, [requests]);

  // Load head assignments for current user
  const loadHead = async () => {
    try {
      const ids = await projectRequestService.getHeadAssignmentsForCurrentUser();
      setMyHeadIds(ids || []);
    } catch {
      setMyHeadIds([]);
    }
  };

  // Initial load of head assignments
  React.useEffect(() => {
    loadHead();
  }, []);

  // Refresh head assignments when returning from head‑assign page
  React.useEffect(() => {
    if (!location.pathname.includes("head-assign")) {
      loadHead();
    }
  }, [location.pathname]);

  const displayed = React.useMemo(() => {
    return viewFilter === "mine"
      ? filtered.filter((r) => myHeadIds.includes(r.id))
      : filtered;
  }, [filtered, myHeadIds, viewFilter]);

  const formatTimeAgo = (iso: string) => {
    const d = new Date(iso);
    const now = new Date();
    const diffMs = now.getTime() - d.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);
    if (diffMins < 60) return `${diffMins} min ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
  };

  // Mock notifications (last 3 recent requests)
  const notifications = React.useMemo(() => {
    const recent = requests
      .filter((r) => {
        const created = new Date(r.createdDate);
        const diffDays = (new Date().getTime() - created.getTime()) / (1000 * 60 * 60 * 24);
        return diffDays <= 1;
      })
      .slice(0, 3);
    return recent.map((r, idx) => ({
      id: r.id,
      type: idx === 0 ? "new" : idx === 1 ? "update" : "reminder",
      message:
        idx === 0
          ? `New request from ${r.businessDepartment || "Unknown Dept"}`
          : idx === 1
            ? `Evaluation completed for "${r.requestTitle}"`
            : `Reminder: ${filtered.length} pending reviews`,
      time: formatTimeAgo(r.createdDate),
      read: idx > 0,
    }));
  }, [requests, filtered.length]);

  const handleAssignReviewers = (requestId: number) => {
    navigate(`/dashboard/${resolvedRole}/requests/${requestId}/assign`);
  };

  const handleViewRequest = (requestId: number) => {
    if (myHeadIds.includes(requestId)) {
      navigate(`/dashboard/${resolvedRole}/requests/${requestId}/head`);
    } else {
      navigate(`/dashboard/${resolvedRole}/requests/${requestId}`);
    }
  };

  const requestColumns = React.useMemo(() => [
    {
      name: "ID",
      selector: (row: ProjectRequestSummary) => row.requestID || row.id,
      sortable: true,
      minWidth: "120px",
      cell: (row: ProjectRequestSummary) => (
        <span className="font-mono font-semibold">#{row.requestID || row.id}</span>
      ),
    },
    {
      name: "Title",
      selector: (row: ProjectRequestSummary) => row.requestTitle,
      sortable: true,
      minWidth: "240px",
      cell: (row: ProjectRequestSummary) => (
        <div>
          <div className="font-medium text-gray-900">{row.requestTitle}</div>
          {row.requestDescription && (
            <div className="text-xs text-gray-500 truncate max-w-[420px]">{row.requestDescription}</div>
          )}
        </div>
      ),
    },
    {
      name: "Requester",
      selector: (row: ProjectRequestSummary) => row.requestedByName || "—",
      sortable: true,
      minWidth: "160px",
    },
    {
      name: "Date",
      selector: (row: ProjectRequestSummary) => row.createdDate,
      sortable: true,
      minWidth: "140px",
    },
    {
      name: "Actions",
      minWidth: "220px",
      cell: (row: ProjectRequestSummary) => (
        <div className="relative inline-block text-left">
          <button
            onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === row.id ? null : row.id); }}
            className="inline-flex items-center justify-center p-2 rounded-full hover:bg-gray-100 focus:outline-none"
          >
            <MoreVertical className="w-4 h-4 text-gray-600" />
          </button>
          {openMenuId === row.id && (
            <div className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-10">
              <div className="py-1" role="menu" aria-orientation="vertical" aria-labelledby="options-menu">
                <button
                  onClick={(e) => { e.stopPropagation(); handleViewRequest(row.id); setOpenMenuId(null); }}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Eye className="inline w-4 h-4 mr-2" />
                  {myHeadIds.includes(row.id) ? "Head Console" : "View"}
                </button>
                {!myHeadIds.includes(row.id) && (
                  <button
                    onClick={(e) => { e.stopPropagation(); navigate(`/dashboard/${resolvedRole}/requests/${row.id}/head-assign`); setOpenMenuId(null); }}
                    className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  >
                    <ShieldCheck className="inline w-4 h-4 mr-2" /> Assign Head
                  </button>
                )}
                <button
                  onClick={(e) => { e.stopPropagation(); handleAssignReviewers(row.id); setOpenMenuId(null); }}
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <UserPlus className="inline w-4 h-4 mr-2" /> Assign Reviewers
                </button>
              </div>
            </div>
          )}
        </div>
      ),
    },
  ], [myHeadIds, navigate, resolvedRole, openMenuId]);

  // Metrics for dashboard cards
  const metrics = React.useMemo(() => {
    const newRequests = requests.filter((r) => ["submitted", "new"].includes(r.status?.toLowerCase() ?? ""));
    const inEvaluation = requests.filter((r) => r.status?.toLowerCase() === "under evaluation");
    const approved = requests.filter((r) => r.status?.toLowerCase() === "approved");
    return {
      new: newRequests.length,
      inEvaluation: inEvaluation.length,
      approved: approved.length,
    };
  }, [requests]);

  return (
    <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        {[{ title: "New Requests", value: metrics.new, icon: FileText, color: "text-yellow-400" },
        { title: "In Evaluation", value: metrics.inEvaluation, icon: Clock, color: "text-yellow-400" },
        { title: "Approved", value: metrics.approved, icon: CheckCircle, color: "text-yellow-400" }]
          .map((card, idx) => (
            <Card key={idx} className="border border-purple-800 bg-purple-900 text-white shadow-md">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
                <card.icon className={`h-4 w-4 ${card.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{card.value}</div>
                <div className="text-xs text-purple-200 mt-1">Updated just now</div>
              </CardContent>
            </Card>
          ))}
      </div>

      {/* Quick Actions and Notifications */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Quick Actions */}
        <Card className="border border-purple-100 bg-white">
          <CardHeader className="pb-3 border-b border-purple-100">
            <CardTitle className="text-gray-900">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <button
                onClick={() => navigate(`/dashboard/${resolvedRole}/requests/head-assign`)}
                className="w-full flex items-center justify-between p-3 rounded-lg bg-purple-50 hover:bg-purple-100 border border-purple-200 transition-colors text-left"
              >
                <div className="flex items-center">
                  <ShieldCheck className="w-5 h-5 text-purple-700 mr-3" />
                  <span className="text-sm font-medium text-gray-800">Assign Head Reviewer</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-500" />
              </button>
              <button
                onClick={() => navigate(`/dashboard/${resolvedRole}/requests/assign`)}
                className="w-full flex items-center justify-between p-3 rounded-lg bg-purple-50 hover:bg-purple-100 border border-purple-200 transition-colors text-left"
              >
                <div className="flex items-center">
                  <Users className="w-5 h-5 text-purple-700 mr-3" />
                  <span className="text-sm font-medium text-gray-800">Assign Reviewers</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-500" />
              </button>
              <button
                onClick={() => navigate(`/dashboard/${resolvedRole}/reports`)}
                className="w-full flex items-center justify-between p-3 rounded-lg bg-yellow-50 hover:bg-yellow-100 border border-yellow-200 transition-colors text-left"
              >
                <div className="flex items-center">
                  <BarChart2 className="w-5 h-5 text-yellow-600 mr-3" />
                  <span className="text-sm font-medium text-gray-800">View Reports</span>
                </div>
                <ArrowRight className="w-4 h-4 text-gray-500" />
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Notifications */}
        <Card className="border border-purple-100 bg-white">
          <CardHeader className="flex items-center justify-between pb-3 border-b border-purple-100">
            <div className="flex items-center">
              <Bell className="w-5 h-5 text-purple-700 mr-2" />
              <CardTitle className="text-gray-900">Notifications</CardTitle>
            </div>
            <span className="px-2 py-1 text-xs font-medium bg-yellow-100 text-yellow-800 rounded-full border border-yellow-300">
              {notifications.filter((n) => !n.read).length} New
            </span>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {notifications.length > 0 ? (
                notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-3 rounded-lg border transition-colors ${!notification.read ? "bg-purple-50 border-purple-200" : "bg-gray-50 border-gray-200"}`}
                  >
                    <div className="flex items-start">
                      <div
                        className={`w-2 h-2 mt-2 rounded-full mr-3 flex-shrink-0 ${notification.type === "new" ? "bg-purple-500" : notification.type === "update" ? "bg-green-500" : "bg-yellow-500"}`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-800">{notification.message}</p>
                        <p className="text-xs text-gray-400 mt-1">{notification.time}</p>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-sm text-gray-500 text-center py-4">No new notifications</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Requests Table */}
      {error && !loading && (
        <div className="mb-4 px-4 py-3 rounded border border-red-200 bg-red-50 text-sm text-red-700">{error}</div>
      )}
      <Card className="border border-purple-100 bg-white">
        <CardHeader className="pb-3 border-b border-purple-100">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3">
            <div className="flex items-center gap-3">
              <h2 className="text-lg font-semibold text-gray-900">Pending Requests</h2>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setViewFilter("all")}
                  className={`px-3 py-1.5 rounded-lg text-xs border ${viewFilter === "all" ? "bg-purple-700 text-white border-purple-700" : "bg-white text-purple-700 border-purple-200 hover:bg-purple-50"}`}
                >All Pending</button>
                <button
                  onClick={() => setViewFilter("mine")}
                  className={`px-3 py-1.5 rounded-lg text-xs border ${viewFilter === "mine" ? "bg-purple-700 text-white border-purple-700" : "bg-white text-purple-700 border-purple-200 hover:bg-purple-50"}`}
                >
                  My Head Assignments
                  <span className="ml-2 inline-flex items-center justify-center text-xs px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-800 border border-yellow-300">
                    {myHeadIds.length}
                  </span>
                </button>
              </div>
            </div>
            <button
              onClick={() => navigate(`/dashboard/${resolvedRole}/requests/new`)}
              className="inline-flex items-center px-4 py-2 rounded-lg bg-teal-600 text-white text-sm font-medium shadow-sm hover:bg-teal-500 transition-colors"
            >
              <Plus className="w-4 h-4 mr-2" />
              New Request
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <DataTables
            data={displayed}
            columns={requestColumns as any}
            onRowClicked={(row: any) => handleViewRequest(row.id)}
            darkMode={!!darkMode}
            loading={loading}
            pagination
            paginationPerPage={10}
            paginationRowsPerPageOptions={[5, 10, 15, 20]}
            searchable
            searchPlaceholder="Search requests..."
            customizableColumns
          />
        </CardContent>
      </Card>
    </div>
  );
};

export default RequestsDashboard;
