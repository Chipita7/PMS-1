import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';

import { motion } from 'framer-motion';
import AttachmentUploader, { AttachmentItem } from '../../components/AttachmentUploader';
import {
  getRequestConfigurations,
  createProjectRequest,
  findConfigIdByName,
  calculatePriorityFromUrgencyAndImpact,
  type RequestConfigurations,
  type ConfigOption,
  type CreateProjectRequestDto
} from '../../services/requestService';

type RequestModel = {
  // Core Identification Fields
  requestId: string;
  referenceNo?: string;
  title: string;
  description?: string;

  // Requestor & Origin Details
  requestedBy: string;
  requestedByName?: string;
  businessSector?: string;
  businessDivision?: string;
  businessDepartment?: string;
  organizationName?: string;
  primaryContactEmail?: string;
  secondaryContactEmail?: string;
  primaryContactPhone?: string;
  secondaryContactPhone?: string;

  // Classification & Metadata
  requestType?: string;
  requestCategory?: string;
  serviceCategory?: string;
  productCategory?: string;
  priorityLevel?: string;
  businessImpact?: string;
  requestUrgency?: string;
  strategicAlignment?: string;
  estimatedCost?: number;
  estimatedBenefit?: number;
  benefitCaptureDuration?: number;
  requestedDeliveryDate?: string;
  riskLevel?: string;
  complexityLevel?: string;

  // Workflow & Status Tracking
  status?: string;
  workflowStage?: string;
  assignedTeam?: string;
  assignedTo?: string;
  createdDate?: string;
  lastUpdatedDate?: string;
  lastUpdatedBy?: string;
  approvalDate?: string;
  requestDurationDays?: number;

  // Attachments
  attachmentList?: AttachmentItem[];
};

// These will be populated from backend configurations

const defaultOrg = 'Commercial Bank of Ethiopia';

const pad2 = (n: number) => n.toString().padStart(2, '0');

const generateRequestId = () => {
  const now = new Date();
  const YYYY = now.getFullYear();
  const MM = pad2(now.getMonth() + 1);
  const DD = pad2(now.getDate());
  const seq = pad2(Math.floor(Math.random() * 99) + 1);
  return `PR${YYYY}${MM}${DD}${seq}`;
};

const SCREENS = {
  SUMMARY: 'summary',
  CLASSIFICATION: 'classification',
  METADATA: 'metadata',
  REQUESTOR_DETAILS: 'requestor_details',
  ATTACHMENTS: 'attachments',
  REVIEW: 'review'
};

const RequestForm: React.FC<{ darkMode?: boolean }> = ({ darkMode = false }) => {
  const navigate = useNavigate();
  const { role } = useParams<{ role: string }>();
  const [currentScreen, setCurrentScreen] = React.useState(SCREENS.SUMMARY);
  const [form, setForm] = React.useState<RequestModel>({
    requestId: generateRequestId(),
    title: '',
    requestedBy: '',
    requestedByName: '',
    organizationName: defaultOrg,
    status: 'Submitted',
    createdDate: new Date().toISOString()
  });
  const [attachmentList, setAttachmentList] = React.useState<AttachmentItem[]>([]);
  const [submitted, setSubmitted] = React.useState<RequestModel | null>(null);
  const [errors, setErrors] = React.useState<Record<string, string>>({});
  const [completedSteps, setCompletedSteps] = React.useState<Set<string>>(new Set());
  // Track the selected option for Strategic Alignment separately so we can
  // show the 'Other' free-text input only when the user explicitly picks Other.
  const [alignmentSelectOption, setAlignmentSelectOption] = React.useState<string>('');

  // Backend configurations
  const [configurations, setConfigurations] = React.useState<RequestConfigurations>({});
  const [loadingConfigs, setLoadingConfigs] = React.useState(true);
  const [submitting, setSubmitting] = React.useState(false);
  const [submitError, setSubmitError] = React.useState<string | null>(null);

  // Fetch configurations on mount
  React.useEffect(() => {
    const fetchConfigurations = async () => {
      try {
        setLoadingConfigs(true);
        const configs = await getRequestConfigurations();
        console.log('📋 Loaded configurations:', {
          ImpactLevels: configs.ImpactLevels?.length || 0,
          UrgencyLevels: configs.UrgencyLevels?.length || 0,
          Priorities: configs.Priorities?.length || 0,
          RiskLevels: configs.RiskLevels?.length || 0,
          ComplexityLevels: configs.ComplexityLevels?.length || 0,
          ImpactUrgencies: configs.ImpactUrgencies?.length || 0
        });
        setConfigurations(configs);
      } catch (error: any) {
        console.error('Failed to fetch configurations:', error);
        setErrors((prev) => ({ ...prev, _general: error.message || 'Failed to load form options. Please refresh the page.' }));
      } finally {
        setLoadingConfigs(false);
      }
    };
    fetchConfigurations();
  }, []);

  const onChange = (k: keyof RequestModel, v: any) => {
    setForm((s) => {
      const updated = { ...s, [k]: v };

      // Auto-calculate priority when urgency or impact changes
      // Only calculate if we have both values and configurations are loaded
      if ((k === 'requestUrgency' || k === 'businessImpact') &&
        configurations.Priorities &&
        configurations.Priorities.length > 0) {
        const calculatedPriority = calculatePriorityFromUrgencyAndImpact(
          updated.requestUrgency,
          updated.businessImpact,
          configurations.Priorities
        );
        if (calculatedPriority) {
          updated.priorityLevel = calculatedPriority;
        } else {
          // Clear priority if calculation fails
          updated.priorityLevel = '';
        }
      }

      return updated;
    });
    setErrors((e) => ({ ...e, [k]: '' }));
  };

  // (We no longer auto-compute completed steps from form values.)

  // cache screens array
  const screensArray = React.useMemo(() => Object.values(SCREENS), []);

  // We mark steps completed only when user clicks Continue and validation passes.
  // number of sequentially completed steps from the start (0..n) — computed from completedSteps
  const numberSequentiallyCompleted = React.useMemo(() => {
    for (let i = 0; i < screensArray.length; i++) {
      if (!completedSteps.has(screensArray[i])) return i;
    }
    return screensArray.length;
  }, [completedSteps, screensArray]);

  // first incomplete index (used to prevent skipping ahead)
  const firstIncompleteIndex = Math.min(screensArray.length - 1, Math.max(0, numberSequentiallyCompleted));

  const validateScreen = (screen: string): boolean => {
    const errs: Record<string, string> = {};

    switch (screen) {
      case SCREENS.SUMMARY:
        if (!form.title) errs.title = 'Request title is required';
        if (!form.description) errs.description = 'Request description is required';
        break;
      case SCREENS.CLASSIFICATION:
        if (!form.requestType) errs.requestType = 'Request type is required';
        if (!form.requestCategory) errs.requestCategory = 'Request category is required';
        if (!form.serviceCategory) errs.serviceCategory = 'Service category is required';
        if (!form.productCategory) errs.productCategory = 'Product category is required';
        if (!form.priorityLevel) errs.priorityLevel = 'Priority level is required';
        if (!form.businessImpact) errs.businessImpact = 'Business impact is required';
        if (!form.requestUrgency) errs.requestUrgency = 'Request urgency is required';
        break;
      case SCREENS.METADATA:
        if (!form.strategicAlignment) errs.strategicAlignment = 'Strategic alignment is required';
        break;
      case SCREENS.ATTACHMENTS:
        // require at least one attachment before continuing from Attachments step
        if (!attachmentList || attachmentList.length === 0) {
          errs.attachments = 'Please upload at least one supporting document to continue';
        }
        break;
      case SCREENS.REQUESTOR_DETAILS:
        if (!form.requestedBy) errs.requestedBy = 'Requested By (AD user ID) is required';
        if (!form.requestedByName) errs.requestedByName = 'Requested By Name is required';
        if (!form.businessSector) errs.businessSector = 'Business Sector is required';
        if (!form.businessDivision) errs.businessDivision = 'Business Division is required';
        if (!form.businessDepartment) errs.businessDepartment = 'Business Department is required';
        if (!form.primaryContactEmail) errs.primaryContactEmail = 'Primary contact email is required';
        if (!form.secondaryContactEmail) errs.secondaryContactEmail = 'Secondary contact email is required';
        if (!form.primaryContactPhone) errs.primaryContactPhone = 'Primary contact phone is required';
        if (!form.secondaryContactPhone) errs.secondaryContactPhone = 'Secondary contact phone is required';
        break;
    }

    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const nextScreen = () => {
    if (!validateScreen(currentScreen)) return;

    // mark the current step as completed when user successfully continues
    setCompletedSteps((prev) => new Set(prev).add(currentScreen));

    const screens = screensArray;
    const currentIndex = screens.indexOf(currentScreen);
    if (currentIndex < screens.length - 1) {
      setCurrentScreen(screens[currentIndex + 1]);
    }
  };

  const prevScreen = () => {
    const screens = screensArray;
    const currentIndex = screens.indexOf(currentScreen);
    if (currentIndex > 0) {
      setCurrentScreen(screens[currentIndex - 1]);
    }
  };

  const handleStepClick = (screen: string) => {
    // Use sequential completion to prevent skipping: only allow up to firstIncompleteIndex
    const screens = screensArray;
    const targetIndex = screens.indexOf(screen);
    const currentIndex = screens.indexOf(currentScreen);

    // allow navigating back or to current
    if (targetIndex <= currentIndex) {
      setCurrentScreen(screen);
      return;
    }

    // if trying to jump ahead beyond the first incomplete step, go to first incomplete
    if (targetIndex > firstIncompleteIndex) {
      setCurrentScreen(screens[firstIncompleteIndex]);
      return;
    }

    // allowed (all previous steps are completed)
    setCurrentScreen(screen);
  };

  const onSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!validateScreen(currentScreen)) return;

    setSubmitting(true);
    setSubmitError(null);

    try {
      // Map form values to backend DTO format
      // Use the correct configuration keys that match what backend returns
      const requestTypeConfigId = findConfigIdByName(configurations.RequestTypes, form.requestType || '');
      const requestCategoryConfigId = findConfigIdByName(configurations.RequestCategories, form.requestCategory || '');
      const serviceCategoryConfigId = findConfigIdByName(configurations.ServiceCategories, form.serviceCategory || '');
      const productCategoryConfigId = findConfigIdByName(configurations.ProductCategories, form.productCategory || '');
      const priorityConfigId = findConfigIdByName(configurations.Priorities, form.priorityLevel || '');

      // Backend returns ImpactLevels, UrgencyLevels, RiskLevels, ComplexityLevels
      // These all use the same ImpactUrgencyConfig data, but with different keys
      const businessImpactConfigId = findConfigIdByName(
        configurations.ImpactLevels || configurations.ImpactUrgencies,
        form.businessImpact || ''
      );
      const requestUrgencyConfigId = findConfigIdByName(
        configurations.UrgencyLevels || configurations.ImpactUrgencies,
        form.requestUrgency || ''
      );
      const riskLevelConfigId = form.riskLevel ? findConfigIdByName(
        configurations.RiskLevels || configurations.ImpactUrgencies,
        form.riskLevel
      ) : undefined;
      const complexityLevelConfigId = form.complexityLevel ? findConfigIdByName(
        configurations.ComplexityLevels || configurations.ImpactUrgencies,
        form.complexityLevel
      ) : undefined;

      // Debug logging
      console.log('🔍 Mapping form to backend DTO:', {
        businessImpact: { value: form.businessImpact, configId: businessImpactConfigId },
        requestUrgency: { value: form.requestUrgency, configId: requestUrgencyConfigId },
        priorityLevel: { value: form.priorityLevel, configId: priorityConfigId },
        riskLevel: { value: form.riskLevel, configId: riskLevelConfigId },
        complexityLevel: { value: form.complexityLevel, configId: complexityLevelConfigId }
      });

      // Validate required config IDs
      if (!requestTypeConfigId || !requestCategoryConfigId || !serviceCategoryConfigId ||
        !productCategoryConfigId || !priorityConfigId || !businessImpactConfigId || !requestUrgencyConfigId) {
        throw new Error('Please ensure all classification fields are properly selected.');
      }

      const createDto: CreateProjectRequestDto = {
        requestTitle: form.title,
        requestDescription: form.description || '',
        referenceNo: form.referenceNo,
        requestTypeConfigId,
        requestCategoryConfigId,
        serviceCategoryConfigId,
        productCategoryConfigId,
        priorityConfigId,
        businessImpactConfigId,
        requestUrgencyConfigId,
        strategicAlignment: form.strategicAlignment || '',
        estimatedCost: form.estimatedCost,
        estimatedBenefit: form.estimatedBenefit,
        benefitCaptureDuration: form.benefitCaptureDuration,
        requestedDeliveryDate: form.requestedDeliveryDate,
        riskLevelConfigId,
        complexityLevelConfigId,
        primaryContactEmail: form.primaryContactEmail || '',
        secondaryContactEmail: form.secondaryContactEmail,
        primaryContactPhone: form.primaryContactPhone || '',
        secondaryContactPhone: form.secondaryContactPhone,
        requestedByName: form.requestedByName,
        businessSector: form.businessSector,
        businessDivision: form.businessDivision,
        businessDepartment: form.businessDepartment,
        organizationName: form.organizationName
      };

      // Submit to backend
      const createdRequest = await createProjectRequest(createDto);

      // Show success
      const payload: RequestModel = {
        ...form,
        attachmentList,
        lastUpdatedDate: new Date().toISOString()
      };
      setSubmitted(payload);
    } catch (error: any) {
      console.error('Failed to submit request:', error);
      setSubmitError(error.message || 'Failed to submit request. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case SCREENS.SUMMARY:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">Request Summary</h3>
              <p className="text-gray-600 mt-2">Provide the basic information about your request</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Request ID *</label>
                  <div className="p-3 rounded-lg border border-gray-300 bg-gray-50">
                    <span className="font-mono text-gray-700 font-bold">{form.requestId}</span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">Automatically generated request identifier</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Reference No</label>
                  <input
                    value={form.referenceNo || ''}
                    onChange={(e) => onChange('referenceNo', e.target.value)}
                    className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200"
                    placeholder="e.g., BR-DVS-012345"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Request Title *</label>
                  <input
                    value={form.title}
                    onChange={(e) => onChange('title', e.target.value)}
                    className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200"
                    placeholder="Brief, descriptive title of the request"
                  />
                  {errors.title && <div className="text-xs text-red-500 mt-2 flex items-center">
                    <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    {errors.title}
                  </div>}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Request Description *</label>
              <textarea
                value={form.description || ''}
                onChange={(e) => onChange('description', e.target.value)}
                rows={4}
                className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 resize-none"
                placeholder="Detailed description of the idea or request..."
              />
              {errors.description && <div className="text-xs text-red-500 mt-2 flex items-center">
                <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                {errors.description}
              </div>}
            </div>
          </motion.div>
        );

      case SCREENS.CLASSIFICATION:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">Classification & Categorization</h3>
              <p className="text-gray-600 mt-2">Categorize your request for proper processing</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {loadingConfigs ? (
                <div className="md:col-span-2 text-center py-8">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
                  <p className="mt-2 text-gray-600">Loading form options...</p>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Request Type *</label>
                    <select
                      value={form.requestType || ''}
                      onChange={(e) => onChange('requestType', e.target.value)}
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                    >
                      <option value="">Select Request Type</option>
                      {configurations.RequestTypes?.map(option => (
                        <option key={option.id} value={option.name}>{option.name}</option>
                      ))}
                    </select>
                    {errors.requestType && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.requestType}
                    </div>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Request Category *</label>
                    <select
                      value={form.requestCategory || ''}
                      onChange={(e) => onChange('requestCategory', e.target.value)}
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                    >
                      <option value="">Select Request Category</option>
                      {configurations.RequestCategories?.map(option => (
                        <option key={option.id} value={option.name}>{option.name}</option>
                      ))}
                    </select>
                    {errors.requestCategory && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.requestCategory}
                    </div>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Service Category *</label>
                    <select
                      value={form.serviceCategory || ''}
                      onChange={(e) => onChange('serviceCategory', e.target.value)}
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                    >
                      <option value="">Select Service Category</option>
                      {configurations.ServiceCategories?.map(option => (
                        <option key={option.id} value={option.name}>{option.name}</option>
                      ))}
                    </select>
                    {errors.serviceCategory && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.serviceCategory}
                    </div>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Product Category *</label>
                    <select
                      value={form.productCategory || ''}
                      onChange={(e) => onChange('productCategory', e.target.value)}
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                    >
                      <option value="">Select Product Category</option>
                      {configurations.ProductCategories?.map(option => (
                        <option key={option.id} value={option.name}>{option.name}</option>
                      ))}
                    </select>
                    {errors.productCategory && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.productCategory}
                    </div>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Business Impact *</label>
                    <select
                      value={form.businessImpact || ''}
                      onChange={(e) => onChange('businessImpact', e.target.value)}
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                    >
                      <option value="">Select Business Impact</option>
                      {(configurations.ImpactLevels || configurations.ImpactUrgencies)?.map(option => (
                        <option key={option.id} value={option.name}>{option.name}</option>
                      ))}
                    </select>
                    {errors.businessImpact && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.businessImpact}
                    </div>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Request Urgency *</label>
                    <select
                      value={form.requestUrgency || ''}
                      onChange={(e) => onChange('requestUrgency', e.target.value)}
                      className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                    >
                      <option value="">Select Request Urgency</option>
                      {(configurations.UrgencyLevels || configurations.ImpactUrgencies)?.map(option => (
                        <option key={option.id} value={option.name}>{option.name}</option>
                      ))}
                    </select>
                    {errors.requestUrgency && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.requestUrgency}
                    </div>}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Priority Level *
                      <span className="ml-2 text-xs font-normal text-teal-600">
                        (Auto-calculated from Urgency & Impact)
                      </span>
                    </label>
                    <div className="relative">
                      <select
                        value={form.priorityLevel || ''}
                        onChange={(e) => onChange('priorityLevel', e.target.value)}
                        disabled={!form.requestUrgency || !form.businessImpact}
                        className={`w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none ${
                          !form.requestUrgency || !form.businessImpact
                            ? 'bg-gray-100 text-gray-500 cursor-not-allowed'
                            : 'bg-teal-50 text-teal-900 font-semibold'
                        }`}
                      >
                        <option value="">
                          {!form.requestUrgency || !form.businessImpact
                            ? 'Select Urgency & Impact first'
                            : 'Priority will be calculated automatically'}
                        </option>
                        {configurations.Priorities?.map(option => (
                          <option key={option.id} value={option.name}>{option.name}</option>
                        ))}
                      </select>
                      {form.priorityLevel && form.requestUrgency && form.businessImpact && (
                        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                          <svg className="w-5 h-5 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                          </svg>
                        </div>
                      )}
                    </div>
                    {form.priorityLevel && form.requestUrgency && form.businessImpact && (
                      <p className="text-xs text-gray-600 mt-1 flex items-center">
                        <svg className="w-3 h-3 mr-1" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                        </svg>
                        Priority automatically set to <strong className="ml-1">{form.priorityLevel}</strong> based on {form.requestUrgency} Urgency and {form.businessImpact} Impact
                      </p>
                    )}
                    {errors.priorityLevel && <div className="text-xs text-red-500 mt-2 flex items-center">
                      <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                      {errors.priorityLevel}
                    </div>}
                  </div>
                </>
              )}
            </div>
          </motion.div>
        );

      case SCREENS.METADATA:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">Additional Metadata</h3>
              <p className="text-gray-600 mt-2">Provide strategic and financial details</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-700 mb-2">Strategic Alignment *</label>
                {/* Allow selecting predefined alignment types or 'Other' to enter a custom value. */}
                <div className="flex gap-3 items-start">
                  <select
                    value={alignmentSelectOption}
                    onChange={(e) => {
                      const v = e.target.value;
                      setAlignmentSelectOption(v);
                      // If user selects 'Other', clear stored strategicAlignment so they can type custom value below
                      if (v === 'Other') {
                        onChange('strategicAlignment', '');
                      } else {
                        onChange('strategicAlignment', v);
                      }
                    }}
                    className="p-3 rounded-lg border border-gray-300 transition-all duration-200 bg-white"
                  >
                    <option value="">Select alignment</option>
                    <option value="Strategic Pillars">Strategic Pillars</option>
                    <option value="Corporate Objective">Corporate Objective</option>
                    <option value="Sector">Sector</option>
                    <option value="Division">Division</option>
                    <option value="Other">Other</option>
                  </select>

                  {/* show free-text input only when the user explicitly selected 'Other' */}
                  {(alignmentSelectOption === 'Other') && (
                    <input
                      placeholder="Specify alignment (if Other)"
                      value={form.strategicAlignment || ''}
                      onChange={(e) => onChange('strategicAlignment', e.target.value)}
                      className="flex-1 p-3 rounded-lg border border-gray-300  transition-all duration-200"
                    />
                  )}
                </div>
                {errors.strategicAlignment && <div className="text-xs text-red-500 mt-2 flex items-center">
                  <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                  {errors.strategicAlignment}
                </div>}
              </div>

              {[
                { label: 'Estimated Cost (ETB)', key: 'estimatedCost', type: 'number', placeholder: 'Rough cost estimate in ETB' },
                { label: 'Estimated Benefit (ETB)', key: 'estimatedBenefit', type: 'number', placeholder: 'Business value or ROI' },
                { label: 'Benefit Capture Duration (months)', key: 'benefitCaptureDuration', type: 'number', placeholder: 'Duration in months' },
                { label: 'Requested Delivery Date', key: 'requestedDeliveryDate', type: 'date' },
              ].map(({ label, key, type, placeholder }) => (
                <div key={key}>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">{label}</label>
                  <input
                    type={type}
                    value={(form as any)[key] || ''}
                    onChange={(e) => onChange(key as keyof RequestModel, type === 'number' ? parseFloat(e.target.value) || undefined : e.target.value)}
                    className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200"
                    placeholder={placeholder}
                  />
                </div>
              ))}

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Risk Level</label>
                <select
                  value={form.riskLevel || ''}
                  onChange={(e) => onChange('riskLevel', e.target.value)}
                  className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                >
                  <option value="">Select Risk Level</option>
                  {(configurations.RiskLevels || configurations.ImpactUrgencies)?.map(option => (
                    <option key={option.id} value={option.name}>{option.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Complexity Level</label>
                <select
                  value={form.complexityLevel || ''}
                  onChange={(e) => onChange('complexityLevel', e.target.value)}
                  className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200 appearance-none bg-white"
                >
                  <option value="">Select Complexity Level</option>
                  {(configurations.ComplexityLevels || configurations.ImpactUrgencies)?.map(option => (
                    <option key={option.id} value={option.name}>{option.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </motion.div>
        );

      case SCREENS.REQUESTOR_DETAILS:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">Requestor Details</h3>
              <p className="text-gray-600 mt-2">Provide your contact and organizational information</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { label: 'Requested By (AD User ID) *', key: 'requestedBy', placeholder: 'e.g., anwarindris', error: errors.requestedBy },
                { label: 'Requested By Name *', key: 'requestedByName', placeholder: 'e.g., Anwar Indris', error: errors.requestedByName },
                { label: 'Business Sector *', key: 'businessSector', error: errors.businessSector },
                { label: 'Business Division *', key: 'businessDivision', error: errors.businessDivision },
                { label: 'Business Department *', key: 'businessDepartment', error: errors.businessDepartment },
                { label: 'Organization Name *', key: 'organizationName' },
                { label: 'Primary Contact Email *', key: 'primaryContactEmail', type: 'email', placeholder: 'e.g., anwarindris@cbe.com.et', error: errors.primaryContactEmail },
                { label: 'Secondary Contact Email *', key: 'secondaryContactEmail', type: 'email', error: errors.secondaryContactEmail },
                { label: 'Primary Contact Phone *', key: 'primaryContactPhone', placeholder: 'e.g., +251-911-098765', error: errors.primaryContactPhone },
                { label: 'Secondary Contact Phone *', key: 'secondaryContactPhone', error: errors.secondaryContactPhone },
              ].map(({ label, key, type, placeholder, error }) => (
                <div key={key}>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">{label}</label>
                  <input
                    type={type || 'text'}
                    value={(form as any)[key] || ''}
                    onChange={(e) => onChange(key as keyof RequestModel, e.target.value)}
                    className="w-full p-3 rounded-lg border border-gray-300 focus:border-teal-500 focus:ring-2 focus:ring-teal-200 transition-all duration-200"
                    placeholder={placeholder}
                  />
                  {error && <div className="text-xs text-red-500 mt-2 flex items-center">
                    <svg className="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    {error}
                  </div>}
                </div>
              ))}
            </div>
          </motion.div>
        );

      case SCREENS.ATTACHMENTS:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">Attachments & Documents</h3>
              <p className="text-gray-600 mt-2">Upload supporting documents for your request</p>
            </div>

            <div className="bg-gray-50 rounded-lg p-6 border border-gray-200">
              <p className="text-sm text-gray-700 mb-4">
                Upload supporting documents such as Business Case, Cost Estimates, Business Requirement Document,
                Business Feasibility Report, Technical Feasibility Report, UAT Test Report, INSA Security Certificate,
                Security Clearance, Request Memo, Resource Assignment Memo.
              </p>

              <AttachmentUploader
                darkMode={darkMode}
                attachmentList={attachmentList}
                setAttachmentList={setAttachmentList}
                uploadedBy={form.requestedBy || 'system'}
              />
              {errors.attachments && (
                <div className="text-sm text-red-500 mt-3">{errors.attachments}</div>
              )}
            </div>
          </motion.div>
        );

      case SCREENS.REVIEW:
        return (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-900">Review & Submit</h3>
              <p className="text-gray-600 mt-2">Please verify all information before submission</p>
            </div>

            <div className="space-y-6">
              {/* Core Information */}
              <div className="bg-white rounded-lg p-6 border border-gray-300 shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Core Information
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Request ID</span>
                    <span className="text-gray-900 font-mono text-base">{form.requestId}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Reference No</span>
                    <span className="text-gray-900">{form.referenceNo || 'Not provided'}</span>
                  </div>
                  <div className="md:col-span-2 py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Request Title</span>
                    <span className="text-gray-900 text-base">{form.title}</span>
                  </div>
                  <div className="md:col-span-2 py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Description</span>
                    <p className="text-gray-900 text-base whitespace-pre-wrap">{form.description || 'Not provided'}</p>
                  </div>
                </div>
              </div>

              {/* Classification */}
              <div className="bg-white rounded-lg p-6 border border-gray-300 shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                  </svg>
                  Classification & Categorization
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Request Type</span>
                    <span className="text-gray-900">{form.requestType || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Request Category</span>
                    <span className="text-gray-900">{form.requestCategory || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Service Category</span>
                    <span className="text-gray-900">{form.serviceCategory || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Product Category</span>
                    <span className="text-gray-900">{form.productCategory || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Business Impact</span>
                    <span className="text-gray-900">{form.businessImpact || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Request Urgency</span>
                    <span className="text-gray-900">{form.requestUrgency || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Priority Level</span>
                    <span className="text-gray-900 font-semibold">{form.priorityLevel || 'Not provided'}</span>
                    {form.priorityLevel && form.requestUrgency && form.businessImpact && (
                      <span className="text-xs text-gray-500 block mt-1">
                        (Auto-calculated from {form.requestUrgency} Urgency and {form.businessImpact} Impact)
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Metadata */}
              <div className="bg-white rounded-lg p-6 border border-gray-300 shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                  </svg>
                  Additional Metadata
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Strategic Alignment</span>
                    <span className="text-gray-900">{form.strategicAlignment || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Requested Delivery Date</span>
                    <span className="text-gray-900">
                      {form.requestedDeliveryDate
                        ? new Date(form.requestedDeliveryDate).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })
                        : 'Not provided'}
                    </span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Estimated Cost (ETB)</span>
                    <span className="text-gray-900">
                      {form.estimatedCost
                        ? new Intl.NumberFormat('en-ET', {
                          style: 'currency',
                          currency: 'ETB'
                        }).format(form.estimatedCost)
                        : 'Not provided'}
                    </span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Estimated Benefit (ETB)</span>
                    <span className="text-gray-900">
                      {form.estimatedBenefit
                        ? new Intl.NumberFormat('en-ET', {
                          style: 'currency',
                          currency: 'ETB'
                        }).format(form.estimatedBenefit)
                        : 'Not provided'}
                    </span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Benefit Capture Duration</span>
                    <span className="text-gray-900">
                      {form.benefitCaptureDuration
                        ? `${form.benefitCaptureDuration} month${form.benefitCaptureDuration !== 1 ? 's' : ''}`
                        : 'Not provided'}
                    </span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Risk Level</span>
                    <span className="text-gray-900">{form.riskLevel || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Complexity Level</span>
                    <span className="text-gray-900">{form.complexityLevel || 'Not provided'}</span>
                  </div>
                </div>
              </div>

              {/* Requestor Details */}
              <div className="bg-white rounded-lg p-6 border border-gray-300 shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                  Requestor Details
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Requested By (AD User ID)</span>
                    <span className="text-gray-900">{form.requestedBy || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Requested By Name</span>
                    <span className="text-gray-900">{form.requestedByName || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Business Sector</span>
                    <span className="text-gray-900">{form.businessSector || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Business Division</span>
                    <span className="text-gray-900">{form.businessDivision || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Business Department</span>
                    <span className="text-gray-900">{form.businessDepartment || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Organization Name</span>
                    <span className="text-gray-900">{form.organizationName || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Primary Contact Email</span>
                    <span className="text-gray-900">{form.primaryContactEmail || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Secondary Contact Email</span>
                    <span className="text-gray-900">{form.secondaryContactEmail || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Primary Contact Phone</span>
                    <span className="text-gray-900">{form.primaryContactPhone || 'Not provided'}</span>
                  </div>
                  <div className="py-2">
                    <span className="text-sm font-medium text-gray-600 block mb-1">Secondary Contact Phone</span>
                    <span className="text-gray-900">{form.secondaryContactPhone || 'Not provided'}</span>
                  </div>
                </div>
              </div>

              {/* Attachments */}
              <div className="bg-white rounded-lg p-6 border border-gray-300 shadow-sm">
                <h4 className="font-semibold text-gray-900 mb-4 pb-3 border-b border-gray-200 flex items-center">
                  <svg className="w-5 h-5 mr-2 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                  </svg>
                  Attachments & Documents
                </h4>
                <div className="mt-4">
                  {attachmentList.length > 0 ? (
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600 mb-3">
                        <strong>{attachmentList.length}</strong> file{attachmentList.length !== 1 ? 's' : ''} attached
                      </p>
                      <div className="space-y-2">
                        {attachmentList.map((attachment, index) => (
                          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-200">
                            <div className="flex items-center flex-1 min-w-0">
                              <svg className="w-5 h-5 text-gray-500 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                              </svg>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">{attachment.name}</p>
                                <p className="text-xs text-gray-500">
                                  {attachment.size ? `${(attachment.size / 1024).toFixed(2)} KB` : 'Size unknown'}
                                  {attachment.type && ` • ${attachment.type}`}
                                </p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <p className="text-sm text-gray-500">No attachments provided</p>
                  )}
                </div>
              </div>

              {/* Submission Notice */}
              <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
                <div className="flex items-start">
                  <svg className="w-5 h-5 text-blue-600 mr-3 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <h5 className="text-sm font-semibold text-blue-900 mb-1">Ready to Submit</h5>
                    <p className="text-sm text-blue-800">
                      Please review all information above before submitting. Once submitted, your request will be processed
                      and you will receive a confirmation email. You can track the status of your request using the Request ID:
                      <strong className="font-mono ml-1">{form.requestId}</strong>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  const getScreenTitle = (screen: string) => {
    const titles = {
      [SCREENS.SUMMARY]: 'Summary',
      [SCREENS.CLASSIFICATION]: 'Classification',
      [SCREENS.METADATA]: 'Metadata',
      [SCREENS.REQUESTOR_DETAILS]: 'Requestor',
      [SCREENS.ATTACHMENTS]: 'Attachments',
      [SCREENS.REVIEW]: 'Review'
    };
    return titles[screen] || 'Request Form';
  };

  const getScreenIcon = (screen: string) => {
    const icons = {
      [SCREENS.SUMMARY]: '1',
      [SCREENS.CLASSIFICATION]: '2',
      [SCREENS.METADATA]: '3',
      [SCREENS.REQUESTOR_DETAILS]: '4',
      [SCREENS.ATTACHMENTS]: '5',
      [SCREENS.REVIEW]: '6'
    };
    return icons[screen] || '●';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <button
                onClick={() => navigate(`/dashboard/${role}/requests`)}
                className="mr-4 p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ChevronLeft className="w-5 h-5 text-gray-700" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-teal-900">
                  Idea Intake
                </h1>
                <p className="text-gray-600 text-sm">Submit a new project or idea request</p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xl font-semibold text-teal-900">
                Commercial Bank of Ethiopia
              </div>
              <div className="text-sm font-medium text-teal-700">
                Digital Factory
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-8">
        <motion.div
          key={currentScreen}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden"
        >
          {/* Dribbble-style Progress Indicator */}
          <div className="px-8 py-8 bg-white">
            <div className="relative">
              {/* Main connecting line - starts/ends outside the step circles so it doesn't run under them */}
              <div className="absolute top-4 left-10 right-10 h-1 bg-gray-200 -translate-y-1/2 -z-10 rounded-full">
                {/* Progress fill - teal */}
                <motion.div
                  className="absolute top-0 left-0 h-full bg-teal-600 rounded-full"
                  initial={{ width: '0%' }}
                  animate={{
                    width: `${(numberSequentiallyCompleted / (screensArray.length - 1)) * 100}%`
                  }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                />
              </div>

              <div className="flex justify-between relative z-10">
                {screensArray.map((screen, index) => {
                  const isActive = currentScreen === screen;
                  const isCompleted = completedSteps.has(screen);
                  const screenIndex = index;
                  const isClickable = screenIndex <= firstIncompleteIndex || screenIndex <= screensArray.indexOf(currentScreen);
                  const isFutureStep = index > numberSequentiallyCompleted;

                  return (
                    <div key={screen} className="flex flex-col items-center flex-1 relative mt-3">
                      {/* per-step connectors removed — single track above covers progress, and it now starts/ends outside circles */}

                      {/* Step circle with gradient colors */}
                      <button
                        onClick={() => isClickable && handleStepClick(screen)}
                        disabled={!isClickable}
                        className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold transition-all duration-200 relative ${isClickable ? 'hover:scale-105 cursor-pointer' : 'cursor-not-allowed'
                          } ${isCompleted
                            ? 'bg-gradient-to-r from-yellow-400 to-yellow-500 text-white shadow-md'
                            : isActive
                              ? 'bg-teal-600 text-white shadow-md ring-2 ring-teal-300'
                              : 'bg-white border-2 border-gray-300 text-gray-400'
                          } ${isFutureStep ? 'opacity-60' : 'opacity-100'}`}
                        // ensure step circles render above the track
                        style={{ zIndex: 20 }}
                      >
                        {/* Checkmark for completed steps */}
                        {isCompleted ? (
                          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                          </svg>
                        ) : (
                          <span className={`text-sm font-bold ${isActive ? 'text-white' : 'text-gray-500'
                            }`}>
                            {getScreenIcon(screen)}
                          </span>
                        )}

                        {/* Active step indicator dot */}
                        {isActive && !isCompleted && (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            className="absolute -bottom-1 w-2 h-2 bg-teal-600 rounded-full ring-2 ring-white"
                          />
                        )}
                      </button>

                      {/* Step label */}
                      <button
                        onClick={() => isClickable && handleStepClick(screen)}
                        disabled={!isClickable}
                        className={`mt-3 text-xs font-medium transition-colors duration-200 px-2 py-1 rounded ${isActive ? 'text-teal-900 font-semibold' :
                            isCompleted ? 'text-yellow-700' : 'text-gray-500'
                          } ${isClickable ? 'cursor-pointer hover:text-teal-900' : 'cursor-not-allowed opacity-60'}`}
                      >
                        {getScreenTitle(screen)}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Form content with side padding - constrained inner width to prevent fields growing with card */}
          <div className="px-8 pb-8">
            <div className="max-w-4xl mx-auto px-4 lg:px-8">
              <form onSubmit={onSubmit}>
                {renderScreen()}

                {/* Navigation buttons */}
                <div className="mt-12 flex justify-between items-center pt-8 border-t border-gray-100">
                  <button
                    type="button"
                    onClick={prevScreen}
                    disabled={currentScreen === SCREENS.SUMMARY}
                    className={`px-6 py-3 rounded-lg font-medium transition-all duration-200 flex items-center space-x-2 ${currentScreen === SCREENS.SUMMARY
                        ? 'opacity-50 cursor-not-allowed text-gray-400'
                        : 'text-teal-700 hover:text-teal-900 hover:bg-teal-50'
                      }`}
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                    <span>Previous</span>
                  </button>

                  <div className="flex items-center space-x-4">
                    {currentScreen !== SCREENS.REVIEW ? (
                      <button
                        type="button"
                        onClick={nextScreen}
                        className="px-6 py-3 rounded-lg font-medium text-white bg-teal-600 hover:bg-teal-500 transition-all duration-200 shadow-sm hover:shadow-md flex items-center space-x-2"
                      >
                        <span>Continue</span>
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      </button>
                    ) : (
                      <button
                        type="submit"
                        disabled={submitting}
                        className={`px-6 py-3 rounded-lg font-medium text-white bg-teal-600 hover:bg-teal-500 transition-all duration-200 shadow-sm hover:shadow-md flex items-center space-x-2 ${submitting ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        {submitting ? (
                          <>
                            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                            <span>Submitting...</span>
                          </>
                        ) : (
                          <>
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                            </svg>
                            <span>Submit Request</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </form>

              {/* Error message display */}
              {submitError && (
                <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-start">
                    <svg className="w-5 h-5 text-red-600 mr-2 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                    </svg>
                    <div className="flex-1">
                      <h3 className="text-sm font-semibold text-red-800">Submission Error</h3>
                      <p className="text-sm text-red-700 mt-1">{submitError}</p>
                    </div>
                    <button
                      onClick={() => setSubmitError(null)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                </div>
              )}

              {/* General error from config loading */}
              {errors._general && (
                <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-start">
                    <svg className="w-5 h-5 text-yellow-600 mr-2 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    <div className="flex-1">
                      <p className="text-sm text-yellow-800">{errors._general}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      </div>

      {submitted && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            className="w-full max-w-2xl mx-4"
          >
            <div className="bg-white rounded-2xl shadow-2xl border border-gray-200 overflow-hidden">
              <div className="p-8">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-teal-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">Request Submitted Successfully</h2>
                  <motion.div
                    initial={{ y: 10, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    transition={{ delay: 0.2 }}
                    className="text-gray-600"
                  >
                    <p>Thank you for your submission. Your request has been recorded and will be processed shortly.</p>
                  </motion.div>
                  <div className="mt-4 px-4 py-2 bg-teal-50 rounded-lg inline-block border border-teal-200">
                    <span className="text-sm text-teal-900 font-mono font-semibold">{submitted.requestId}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm mb-8">
                  <div className="space-y-3">
                    <div><strong className="text-gray-700">Title:</strong> {submitted.title}</div>
                    <div><strong className="text-gray-700">Request Type:</strong> {submitted.requestType || '—'}</div>
                    <div><strong className="text-gray-700">Priority:</strong> {submitted.priorityLevel || '—'}</div>
                  </div>
                  <div className="space-y-3">
                    <div><strong className="text-gray-700">Requested By:</strong> {submitted.requestedBy}</div>
                    <div><strong className="text-gray-700">Organization:</strong> {submitted.organizationName}</div>
                    <div><strong className="text-gray-700">Attachments:</strong> {(submitted.attachmentList || []).length} files</div>
                  </div>
                </div>

                <div className="flex justify-center space-x-3">
                  <button
                    className="px-6 py-3 rounded-lg font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 transition-all duration-200 border border-gray-300"
                    onClick={() => {
                      setSubmitted(null);
                      navigate(`/dashboard/${role}/requests`);
                    }}
                  >
                    View All Requests
                  </button>
                  <button
                    className="px-6 py-3 rounded-lg font-medium text-white bg-teal-600 hover:bg-teal-500 transition-all duration-200 shadow-sm hover:shadow-md"
                    onClick={() => {
                      setSubmitted(null);
                      // Reset form for new request
                      setForm({
                        requestId: generateRequestId(),
                        title: '',
                        description: '',
                        requestedBy: '',
                        requestedByName: '',
                        organizationName: defaultOrg,
                        status: 'Submitted',
                        createdDate: new Date().toISOString()
                      });
                      setAttachmentList([]);
                      setCompletedSteps(new Set());
                      setCurrentScreen(SCREENS.SUMMARY);
                    }}
                  >
                    Create Another
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default RequestForm;