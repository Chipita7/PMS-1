﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ProjectManagementSystem1.Migrations
{
    /// <inheritdoc />
    public partial class AddMilestoneAndProjectAssignmentApproval : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "AssignmentAcceptedDate",
                table: "ProjectAssignments",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "AssignmentAcceptedDate",
                table: "Milestones",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AssignmentRejectionReason",
                table: "Milestones",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "AssignmentStatus",
                table: "Milestones",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "AssignmentAcceptedDate",
                table: "ProjectAssignments");

            migrationBuilder.DropColumn(
                name: "AssignmentAcceptedDate",
                table: "Milestones");

            migrationBuilder.DropColumn(
                name: "AssignmentRejectionReason",
                table: "Milestones");

            migrationBuilder.DropColumn(
                name: "AssignmentStatus",
                table: "Milestones");
        }
    }
}
